# Physical phone acceptance record

Use the Vercel HTTPS address and the new Test_Barcodes_100.pdf printed at 100%. Test at least one Android phone and one iPhone. Record model, operating system, browser version, connection and lighting. No physical-device results have been entered in this file.

| Case | Expected behaviour | Actual result and time |
|---|---|---|
| Start camera and allow access | Rear camera where available; readable preview | Pending |
| Scan DEMO-0001 | Correct ID retrieved; account/CT confirmation still required | Pending |
| Scan a QR label | Same ID as its Code 128 counterpart | Pending |
| Turn phone portrait and landscape | Controls remain usable without horizontal overflow | Pending |
| Deny camera permission | Clear explanation; photograph/manual alternatives usable | Pending |
| Photograph a label | ID decoded and retrieved | Pending |
| Stop while camera starts | Late camera stream is released; indicator turns off | Pending |
| Switch away from the page | Active camera stops | Pending |
| Scan an unknown barcode | No connection request or invented record | Pending |
| Wrong account or CT | Request rejected; meter not connected | Pending |
| DEMO-0061 automatic attempt | Manual HES queue; failure reason; three notification records | Pending |
| Repeat a failed scan | No automatic commissioning retry | Pending |
| HES officer verifies completion | Matching receipt required before connected status | Pending |
| Connection interrupted | No client-only success; reconcile pending server state | Pending |
| Repeat a connected scan | Existing result, no duplicate commissioning request | Pending |
| Inspect notifications | Channel and mode visible; simulated is not delivered | Pending |

Use a fresh development register for repeatable expected states. Keep real utility records out of a public demonstration. Sign off device acceptance only after recording actual outcomes.
